@app.route('pages/forms/scam_prevention', methods=['GET', 'POST'])
# def scam_prevention():
#     form = ScamPreventionForm()
#     if form.validate_on_submit():
#         # Process the form data and generate output
#         return redirect(url_for('home', alert='Scam Prevention model executed successfully'))
#     return render_template('scam_prevention.html', form=form, title='Scam Prevention')